package com.capgemini.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.model.Author;
import com.capgemini.model.Author;
import com.capgemini.model.Author;
import com.capgemini.model.Author;



public class AuthorDao {
	public void addAuthor(Author author) {
		//jpa logic to perform insert operation
		EntityManagerFactory emf =null;
		EntityManager em =null;
		try {
			emf = Persistence.createEntityManagerFactory("Lab1");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			em.persist(author);
			em.getTransaction().commit();
			System.out.println("Author added");
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();
			}
		}
		
		
	}
	public void getAuthor(Integer authorId) {
		//jpa logic to perform insert operation
		EntityManagerFactory emf =null;
		EntityManager em =null;
		try {
			emf = Persistence.createEntityManagerFactory("Lab1");
			em = emf.createEntityManager();
			em.getTransaction().begin();
			Author author = em.find(Author.class,authorId);
			if(author!=null) {
			System.out.println("author details:" + author.getFirstName()+ " "+ author.getMiddleName() + " " + author.getLastName()+ " "+author.getPhoneNo());
			}
			else {
				System.out.println("No author Id present");
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();
			}
		}
		
	}
	public void updateAuthor(String firstName, String middleName, String lastName, Integer phoneNo, Integer authorId) {
		//jpa logic to perform insert operation
				EntityManagerFactory emf =null;
				EntityManager em =null;
				try {
					emf = Persistence.createEntityManagerFactory("Lab1");
					em = emf.createEntityManager();
					Author author = em.find(Author.class,authorId);
					if(author!=null) {
						em.getTransaction().begin();
						author.setFirstName(firstName);
						author.setMiddleName(middleName);
						author.setLastName(lastName);
						author.setPhoneNo(phoneNo);
						em.getTransaction().commit();
						System.out.println("Author updated");
					}
					else {
						System.out.println("No author Id present");
					}
				}
				catch(Exception ex) {
					ex.printStackTrace();
				}
				finally {
					if(em!=null && emf!=null) {
						em.close();
						emf.close();
					}
				}
		
	}
	public void deleteAuthor(Integer authorId) {
		//jpa logic to perform insert operation
		EntityManagerFactory emf =null;
		EntityManager em =null;
		try {
			emf = Persistence.createEntityManagerFactory("Lab1");
			em = emf.createEntityManager();
			Author author = em.find(Author.class,authorId);
			if(author!=null) {
				em.getTransaction().begin();
				em.remove(author);
				em.getTransaction().commit();
				System.out.println("author is deleted");
			}
			else {
				System.out.println("No author Id present");
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
			if(em!=null && emf!=null) {
				em.close();
				emf.close();
			}
		}
		
	}

}
