package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.dao.AuthorDao;
import com.capgemini.model.Author;



public class AuthorMain {
static void showDashbord() {
		
		System.out.println("*****Dashboard*****");
		System.out.println("1.Add Author \n2.Show Author Details \n3.Update Author \n4.Delete Author \n5.Exit");
		
	}
	public static void main(String[] args) {
		AuthorDao dao = new AuthorDao();
		
		
		Scanner sc = new Scanner(System.in);
		
		
		while(true) {
			showDashbord();
			System.out.println("Enter choice:");
			String choice = sc.next();
			
		
			switch(choice) {
			case "1":
				Author author = new Author();
				Integer authorId;
				//System.out.print("enter id:");
				//int id = sc.nextInt();
			
				System.out.print("\nenter first name:");
				String firstName  = sc.next();
			
				System.out.print("\nenter middleName:");
				String middleName = sc.next();
			
				System.out.print("\nenter lastName:");
				String lastName  = sc.next();
				
				System.out.print("\nenter Phone No.:");
				Integer phoneNo  = sc.nextInt();
				
			
			author.setFirstName(firstName);
			author.setMiddleName(middleName);
			author.setLastName(lastName);
			author.setPhoneNo(phoneNo);
				
				dao.addAuthor(author);
			
				break;
			case "2":
				System.out.print("enter id:");
				authorId = sc.nextInt();
				dao.getAuthor(authorId);
				break;
				
			case "3":
				System.out.print("enter id:");
			authorId = sc.nextInt();
			System.out.print("\nenter first name:");
			firstName = sc.next();
			System.out.print("\nenter middleName:");
			 middleName = sc.next();
		
			System.out.print("\nenter lastName:");
			 lastName  = sc.next();
			
			System.out.print("\nenter Phone No.:");
			 phoneNo  = sc.nextInt();
			dao.updateAuthor(firstName, middleName, lastName, phoneNo, authorId);
			break;
			
			case "4":
				System.out.print("enter id:");
				authorId = sc.nextInt();
				dao.deleteAuthor(authorId);
				break;
		default:
			System.out.println("wrong choice");
		}
		
		}
		
	}
}

