package com.lab2.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lab2.model.Admin;
import com.lab2.model.Trainee;



public interface TraineeDao  extends JpaRepository<Trainee, Integer> {

}
