package com.lab2.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.lab2.model.Admin;
import com.lab2.model.Trainee;
import com.lab2.service.TraineeService;

@Controller
public class TraineeController {
	Trainee deleteTrainee,updateTrainee;
	@Autowired
	TraineeService service;
	
	 @RequestMapping(value="/", method=RequestMethod.GET) 
	  public  ModelAndView loadAddEmployee() {
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("index");
		  mav.addObject("admin", new Admin()); 
		  return mav; 
	  }
	 
	 @RequestMapping(value="/", method=RequestMethod.POST)
		public ModelAndView loginAdmin(@ModelAttribute("admin")  @Valid  Admin admin, BindingResult bindingResult) {	
		 
		 if (bindingResult.hasErrors()) {		
			System.out.println("wrong input");
			return null;
	     }
		 else {
			boolean result = service.loginAdmin(admin);
			ModelAndView mav = new ModelAndView("index");
			if(result) {
				ModelAndView mv = new ModelAndView(); 
				mv.setViewName("home");
				return mv;
			}
			else {
				String message = "login failed";
				mav.addObject("successMessage", message);
				return mav;
			}
		 }
		}
	 
	 @RequestMapping(value="/home", method=RequestMethod.GET) 
	  public  ModelAndView loadHomePage() {
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("home");
		  return mav; 
	  }
	 
	 @RequestMapping(value="/addTraineePage")
		public ModelAndView getAddTraineePage()
		{
			ModelAndView mv=new ModelAndView("addTrainee");
			mv.addObject("trainee",new Trainee());
			return mv;
		}

		@RequestMapping(value="/addTrainee")
		public ModelAndView getAddTraineeDetails(@ModelAttribute Trainee trainee)
		{
			boolean result = service.addTrainee(trainee);
			ModelAndView mav = new ModelAndView("addTrainee");
			String message = "Trainee added Successfully";
			mav.addObject("successMessage", message);
			return mav;
		}
		
		 @RequestMapping(value="/deleteTraineePage")
			public ModelAndView getdeleteTraineePage()
			{
				ModelAndView mv=new ModelAndView("deleteTrainee");
				mv.addObject("trainee",new Trainee());
				return mv;
			}
		 
		@RequestMapping(value="/getDeleteTraineeDetail")
		public ModelAndView getDeleteTraineeDetail(@ModelAttribute("trainee") Trainee trainee,Model model)
		{
			ModelAndView mv=new ModelAndView("deleteTrainee");	
			int tid = trainee.getTraineeId();
			trainee=service.getTrainee(tid);
			deleteTrainee = trainee;
			if(trainee!=null)
			{
				mv=new ModelAndView("deleteTrainee");
				mv.addObject("trainee1",trainee);
				
			}
			else if(trainee==null)
			{
				String message = "Trainee Not Found";
				mv.addObject("errorMessage", message);	
			}
			return mv;
		}
		
		@RequestMapping(value="/deleteTrainee")
		public ModelAndView deleteTrainee(@ModelAttribute("trainee1") Trainee trainee1,Model model)
		{
			
			ModelAndView mv;
			boolean	result=service.deleteTrainee(deleteTrainee.getTraineeId());

			if(result)
			{		
				mv=new ModelAndView("home");
				return mv;
			}
			else
			{
				String message = "Technical Problem";	
				mv=new ModelAndView("deleteTrainee");
				mv.addObject("successMessage", message);
				return mv;
			}
		
		}
		
		
		@RequestMapping(value="/updateTraineePage", method = RequestMethod.GET)
		public ModelAndView getModifyTraineePage()
		{
			ModelAndView mv=new ModelAndView("updateTrainee");
			mv.addObject("tr",new Trainee());
			return mv;
		}


		@RequestMapping(value="/getUpdateTraineeDetail", method = RequestMethod.POST)
		public ModelAndView getModifyTraineeDetail(@RequestParam("traineeId") Integer traineeId)
		{
				
			updateTrainee=service.getTrainee(traineeId);
			if(updateTrainee!=null)
			{
				//mv=new ModelAndView("updateTrainee");
				ModelAndView mv=new ModelAndView("updateTrainee");
				mv.addObject("tr",new Trainee());
				mv.addObject("trainee",updateTrainee);
				return mv;
			}
			else if(updateTrainee==null)
			{
				ModelAndView mv=new ModelAndView("updateTrainee");	
				String message = "Trainee Not Found";
				mv.addObject("tr",new Trainee());
				mv.addObject("successMessage", message);	
				return mv;
			}
			return null;
			
		}
		
		@RequestMapping(value="/updateTrainee",method = RequestMethod.POST)
		public ModelAndView modifyTrainee(@ModelAttribute("tr") Trainee tr)
		{
			System.out.println("getting trainee data to update" + tr);
					ModelAndView mv=new ModelAndView("updateTrainee");
					
		    		mv.addObject("tr",updateTrainee);
		    		
		    		updateTrainee.setTraineeName(tr.getTraineeName());
		    		updateTrainee.setTraineeDomain(tr.getTraineeDomain());
		    		updateTrainee.setTraineeLocation(tr.getTraineeLocation());
		    				    		
		    		boolean	result=service.updateTrainee(tr);
		        	if(result) {
		        		String message = "Trainee update Successfully";
		        		mv.addObject("successMessage", message);
		        		
		        	}
		        	else {
		        		String message = "Technical Problem";
		        		mv.addObject("successMessage", message);
		        	}
		  return mv;
		}
		
		@RequestMapping(value="/retrieveTraineePage", method=RequestMethod.GET)
		public ModelAndView loadGetEmployeeById() {			
			ModelAndView mav = new ModelAndView("dispTraineeById");		
			return mav;
		}
		
		@RequestMapping(value="/getRetrieveTraineeDetail", method=RequestMethod.POST)
		public ModelAndView getEmployeeById(@RequestParam Integer traineeId) {
			Trainee trainee = service.getTrainee(traineeId);
			System.out.println("found = "+trainee);
			ModelAndView mav = new ModelAndView("dispTraineeById");	
			if(trainee!=null) {
				mav.addObject("trainee", trainee);
			}
			else
				mav.addObject("errorMessage","Employee details not found for the given employee id");
			
			return mav;
		}
		
		
		@RequestMapping(value="/retrieveAllTraineePage", method=RequestMethod.GET)
		public ModelAndView getEmloyees() {
			List<Trainee> alist = service.getAllTrainee();
			ModelAndView mav = new ModelAndView("displayAllTrainee");
			if(alist.isEmpty()) {
				mav.addObject("errorMessage", "No Trainee Found");			
			}
			else {
				mav.addObject("traineeList",alist);			
			}
			
			return mav;
		}
}
