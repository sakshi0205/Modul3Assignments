package com.lab2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lab2.dao.TraineeDao;
import com.lab2.model.Admin;
import com.lab2.model.Trainee;



@Service
public class TraineeService {
	@Autowired
	TraineeDao repository;
	
	@Transactional
	public boolean loginAdmin(Admin admin) {
		if(admin.getUsername().equals("admin") && admin.getPassword().equals("admin123")) {
			return true;
		}
		else {
			return false;
		}
    }
	
	@Transactional
	public boolean addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		if(trainee!=null) {
		repository.saveAndFlush(trainee);
		return true;
		}
		else {
			return false;
		}
	}
	
	public Trainee getTrainee(int tid) {
		Optional<Trainee> opt=repository.findById(tid);
		if(opt.isPresent()) 
			return opt.get();
		else
			return null;
	}

	public boolean deleteTrainee(Integer traineeId) {
		Optional<Trainee> opt=repository.findById(traineeId);
		if(opt.isPresent())
		 {
			Trainee t=opt.get();
			repository.delete(t);
			return true;
			
		 }
		else 
		{
			return false;
		} 
	}

	public boolean updateTrainee(Trainee tr) {
		if(tr!=null) {
			repository.save(tr);
			return true;
		}
		else {
			return false;
		}
	}

	public List<Trainee> getAllTrainee() {
		return repository.findAll();
	}

}
