package com.productclient.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.productclient.entity.ProductEntity;
import com.productclient.exception.NoSuchProductException;
import com.productclient.repository.ProductRepository;


@Service
public class ProductService {
	@Autowired
	ProductRepository productRepository;
	
	@Transactional
	public String insertProduct(ProductEntity product) {
		ProductEntity entity =  new ProductEntity();
		entity.setProductName(product.getProductName());
		entity.setProductPrice(product.getProductPrice());
		productRepository.saveAndFlush(entity);
		return "Product with Product id "+entity.getProductId() + " added successfully";
    }
	
	public ProductEntity findProduct(int productId) throws NoSuchProductException {
		Optional<ProductEntity> opt=productRepository.findById(productId);
		if(opt.isPresent()) {
			ProductEntity entity=opt.get();
			ProductEntity product = new ProductEntity();
			product.setProductId(entity.getProductId());
			product.setProductName(entity.getProductName());
			product.setProductPrice(entity.getProductPrice());
			return product;
		}
		else {
			throw new NoSuchProductException("Product with " + productId + " does not exist");
		}
	
	}
	public List<ProductEntity> getProducts() {
		List<ProductEntity> entityList= productRepository.findAll();
		
		List<ProductEntity>list = new ArrayList();
		for (ProductEntity entity : entityList) {
			ProductEntity product = new ProductEntity();
			product.setProductId(entity.getProductId());
			product.setProductName(entity.getProductName());
			product.setProductPrice(entity.getProductPrice());
			
			list.add(product);
		}
		return list;
}
	public String updateProduct(Integer productId,ProductEntity product) throws NoSuchProductException{
		Optional<ProductEntity> opt=productRepository.findById(productId);
		if(opt.isPresent())
		 {
			ProductEntity entity=opt.get();
			product.setProductName(entity.getProductName());
			product.setProductPrice(entity.getProductPrice());
			
		 } 
		else {
			throw new NoSuchProductException("Employee with " + productId + " does not exist");
		}
		return "Product details updated successfully";
	}
	
	public String removeProduct(int productId) throws NoSuchProductException{
		Optional<ProductEntity> opt=productRepository.findById(productId);
		if(opt.isPresent())
		 {
			ProductEntity emp=opt.get();
		    productRepository.delete(emp);
		 } 
		else {
			throw new NoSuchProductException("Product with " + productId + " does not exist");
		}
		return "Product details deleted successfully";
	}
	

}