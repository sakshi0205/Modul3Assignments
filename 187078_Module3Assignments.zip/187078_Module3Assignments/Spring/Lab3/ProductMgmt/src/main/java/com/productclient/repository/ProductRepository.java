package com.productclient.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.productclient.entity.ProductEntity;


@Repository
public interface ProductRepository extends JpaRepository<ProductEntity, Integer> {
	//@Query("select emp from Employee emp where emp.city = ?1")
    //Employee  findByCity(String city); 
}

