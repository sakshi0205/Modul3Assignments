package com.productclient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.productclient.entity.ProductEntity;
import com.productclient.exception.NoSuchProductException;
import com.productclient.exception.ProductNotFoundException;
import com.productclient.service.ProductService;







@RestController
public class ProductController {
	@Autowired
	ProductService service;
	
	@PostMapping(value="/")
	public ResponseEntity<String> addProduct(@RequestBody ProductEntity product) {
		
		
		String response = service.insertProduct(product);
		//return new ResponseEntity<String>(response, HttpStatus.OK);
		return ResponseEntity.ok(response);
	}
	@GetMapping(value="/")
	public ResponseEntity<List<ProductEntity>> getproduct() throws ProductNotFoundException{ 
		List<ProductEntity> product= service.getProducts();
		return ResponseEntity.ok(product);
	}
	@GetMapping(value="/{productId}")
	public ResponseEntity<ProductEntity> getEmployee(@PathVariable("productId") int productId) throws NoSuchProductException{ 
		ProductEntity product= service.findProduct(productId);
		return ResponseEntity.ok(product);
	}
	@PutMapping(value = "/{productId}")
	public String updateProduct(@PathVariable("productId") int productId, @RequestBody ProductEntity product) throws NoSuchProductException{
		return service.updateProduct(productId, product);
	}
	@DeleteMapping(value = "/{productId}")
	public String deleteProduct(@PathVariable("productId") int productId) throws NoSuchProductException {
		return service.removeProduct(productId);
	}
	
}