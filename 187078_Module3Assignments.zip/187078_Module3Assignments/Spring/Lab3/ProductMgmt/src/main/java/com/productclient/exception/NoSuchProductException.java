package com.productclient.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class NoSuchProductException extends Exception {
		
	public NoSuchProductException() {
		super();
	}
	public NoSuchProductException(String errors) {
		super(errors);
	}
}
