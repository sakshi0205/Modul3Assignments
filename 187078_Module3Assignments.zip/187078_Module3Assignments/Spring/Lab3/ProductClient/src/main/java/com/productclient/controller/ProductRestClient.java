package com.productclient.controller;


import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.productclient.model.Product;


@RestController
public class ProductRestClient {

	@RequestMapping("/home")
	public String home() {

		return "home";
	}


	@RequestMapping(value="/addProduct", method=RequestMethod.GET) 
	public  ModelAndView loadAddProduct() {

		//ModelAndView mav = new ModelAndView("addEmp");
		ModelAndView mav = new ModelAndView(); 
		mav.setViewName("addProduct"); mav.addObject("product", new Product()); 
		return mav; 
	}
	
	@RequestMapping(value="/addProduct", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("product") Product product) {

		RestTemplate restTemplate = new RestTemplate();
		String url="http://localhost:2200/";
		HttpEntity<Product> request = new HttpEntity<>(product);
		String message = restTemplate.postForObject(url, request, String.class);
		ModelAndView mav = new ModelAndView("addProduct");		
		mav.addObject("successMessage", message);
		return mav;
	}
}
