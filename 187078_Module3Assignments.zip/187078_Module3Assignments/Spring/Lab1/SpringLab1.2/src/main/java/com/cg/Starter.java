package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.Employee;

public class Starter {

	public static void main(String[] args) 
	{
	Resource resource=new ClassPathResource("config.xml");
	BeanFactory beanFactory= new XmlBeanFactory(resource);
	Employee employee=(Employee) beanFactory.getBean("Employee");
	
	System.out.println("Employee details");
	System.out.println("---------------------");
	System.out.println(employee);
	}

}