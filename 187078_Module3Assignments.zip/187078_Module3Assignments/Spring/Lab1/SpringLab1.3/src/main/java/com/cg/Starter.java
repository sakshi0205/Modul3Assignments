package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.SBU;

public class Starter {

	public static void main(String[] args) 
	{
	Resource resource=new ClassPathResource("config.xml");
	BeanFactory beanFactory= new XmlBeanFactory(resource);
	SBU employee=(SBU) beanFactory.getBean("SBU");
	
	System.out.println("SBU details");
	System.out.println("---------------------");
	System.out.println(employee);
	}

}