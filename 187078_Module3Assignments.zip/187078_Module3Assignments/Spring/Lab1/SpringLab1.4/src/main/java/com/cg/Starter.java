package com.cg;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Starter {

		public static void main(String[] args) 
		{
			Scanner scanner=new Scanner(System.in);
		Resource resource=new ClassPathResource("config.xml");
		BeanFactory beanFactory= new XmlBeanFactory(resource);
		EmployeeList emplist=(EmployeeList) beanFactory.getBean("EmployeeList");
		boolean flag=false;
		System.out.println("Enter Employee Id :");
		int empId=scanner.nextInt();
		for (Employee employee : emplist.getEmplist()) {
			if(empId==employee.getEmployeeId())
			{flag=true;
				System.out.println("Employee Info:\n"
						+ "Employee Id: "+employee.getEmployeeId()
						+ "\nEmployee Name:"+employee.getEmployeeName()
						+ "\nEmployee Salary:"+employee.getSalary()
						);
			}
			
		}
		if(!flag)
		{
			System.out.println("Invalid id");
		}
		}

	}

